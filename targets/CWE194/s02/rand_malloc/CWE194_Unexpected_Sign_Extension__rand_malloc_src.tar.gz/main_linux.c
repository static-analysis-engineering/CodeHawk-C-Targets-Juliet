#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE194_Unexpected_Sign_Extension__rand_malloc_01_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_02_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_03_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_04_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_05_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_06_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_07_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_08_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_09_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_10_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_11_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_12_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_13_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_14_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_15_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_16_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_17_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_18_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_21_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_22_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_31_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_32_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_34_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_41_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_42_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_44_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_45_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_51_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_52_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_53_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_54_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_61_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_63_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_64_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_65_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_66_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_67_good();
	CWE194_Unexpected_Sign_Extension__rand_malloc_68_good();

	CWE194_Unexpected_Sign_Extension__rand_malloc_01_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_02_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_03_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_04_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_05_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_06_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_07_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_08_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_09_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_10_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_11_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_12_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_13_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_14_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_15_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_16_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_17_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_18_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_21_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_22_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_31_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_32_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_34_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_41_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_42_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_44_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_45_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_51_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_52_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_53_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_54_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_61_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_63_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_64_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_65_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_66_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_67_bad();
	CWE194_Unexpected_Sign_Extension__rand_malloc_68_bad();

	return 0;
}
