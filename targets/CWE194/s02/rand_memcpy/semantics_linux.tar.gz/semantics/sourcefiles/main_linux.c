#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE194_Unexpected_Sign_Extension__rand_memcpy_01_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_02_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_03_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_04_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_05_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_06_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_07_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_08_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_09_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_10_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_11_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_12_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_13_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_14_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_15_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_16_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_17_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_18_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_21_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_22_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_31_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_32_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_34_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_41_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_42_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_44_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_45_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_51_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_52_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_53_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_54_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_61_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_63_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_64_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_65_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_66_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_67_good();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_68_good();

	CWE194_Unexpected_Sign_Extension__rand_memcpy_01_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_02_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_03_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_04_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_05_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_06_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_07_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_08_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_09_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_10_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_11_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_12_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_13_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_14_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_15_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_16_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_17_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_18_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_21_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_22_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_31_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_32_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_34_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_41_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_42_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_44_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_45_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_51_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_52_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_53_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_54_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_61_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_63_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_64_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_65_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_66_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_67_bad();
	CWE194_Unexpected_Sign_Extension__rand_memcpy_68_bad();

	return 0;
}
