#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE197_Numeric_Truncation_Error__short_fgets_01_good();
	CWE197_Numeric_Truncation_Error__short_fgets_02_good();
	CWE197_Numeric_Truncation_Error__short_fgets_03_good();
	CWE197_Numeric_Truncation_Error__short_fgets_04_good();
	CWE197_Numeric_Truncation_Error__short_fgets_05_good();
	CWE197_Numeric_Truncation_Error__short_fgets_06_good();
	CWE197_Numeric_Truncation_Error__short_fgets_07_good();
	CWE197_Numeric_Truncation_Error__short_fgets_08_good();
	CWE197_Numeric_Truncation_Error__short_fgets_09_good();
	CWE197_Numeric_Truncation_Error__short_fgets_10_good();
	CWE197_Numeric_Truncation_Error__short_fgets_11_good();
	CWE197_Numeric_Truncation_Error__short_fgets_12_good();
	CWE197_Numeric_Truncation_Error__short_fgets_13_good();
	CWE197_Numeric_Truncation_Error__short_fgets_14_good();
	CWE197_Numeric_Truncation_Error__short_fgets_15_good();
	CWE197_Numeric_Truncation_Error__short_fgets_16_good();
	CWE197_Numeric_Truncation_Error__short_fgets_17_good();
	CWE197_Numeric_Truncation_Error__short_fgets_18_good();
	CWE197_Numeric_Truncation_Error__short_fgets_21_good();
	CWE197_Numeric_Truncation_Error__short_fgets_22_good();
	CWE197_Numeric_Truncation_Error__short_fgets_31_good();
	CWE197_Numeric_Truncation_Error__short_fgets_32_good();
	CWE197_Numeric_Truncation_Error__short_fgets_34_good();
	CWE197_Numeric_Truncation_Error__short_fgets_41_good();
	CWE197_Numeric_Truncation_Error__short_fgets_42_good();
	CWE197_Numeric_Truncation_Error__short_fgets_44_good();
	CWE197_Numeric_Truncation_Error__short_fgets_45_good();
	CWE197_Numeric_Truncation_Error__short_fgets_51_good();
	CWE197_Numeric_Truncation_Error__short_fgets_52_good();
	CWE197_Numeric_Truncation_Error__short_fgets_53_good();
	CWE197_Numeric_Truncation_Error__short_fgets_54_good();
	CWE197_Numeric_Truncation_Error__short_fgets_61_good();
	CWE197_Numeric_Truncation_Error__short_fgets_63_good();
	CWE197_Numeric_Truncation_Error__short_fgets_64_good();
	CWE197_Numeric_Truncation_Error__short_fgets_65_good();
	CWE197_Numeric_Truncation_Error__short_fgets_66_good();
	CWE197_Numeric_Truncation_Error__short_fgets_67_good();
	CWE197_Numeric_Truncation_Error__short_fgets_68_good();

	CWE197_Numeric_Truncation_Error__short_fgets_01_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_02_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_03_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_04_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_05_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_06_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_07_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_08_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_09_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_10_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_11_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_12_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_13_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_14_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_15_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_16_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_17_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_18_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_21_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_22_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_31_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_32_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_34_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_41_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_42_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_44_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_45_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_51_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_52_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_53_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_54_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_61_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_63_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_64_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_65_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_66_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_67_bad();
	CWE197_Numeric_Truncation_Error__short_fgets_68_bad();

	return 0;
}
