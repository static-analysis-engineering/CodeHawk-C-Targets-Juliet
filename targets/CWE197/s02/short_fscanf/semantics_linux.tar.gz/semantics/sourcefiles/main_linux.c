#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE197_Numeric_Truncation_Error__short_fscanf_01_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_02_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_03_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_04_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_05_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_06_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_07_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_08_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_09_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_10_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_11_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_12_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_13_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_14_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_15_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_16_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_17_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_18_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_21_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_22_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_31_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_32_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_34_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_41_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_42_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_44_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_45_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_51_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_52_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_53_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_54_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_61_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_63_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_64_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_65_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_66_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_67_good();
	CWE197_Numeric_Truncation_Error__short_fscanf_68_good();

	CWE197_Numeric_Truncation_Error__short_fscanf_01_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_02_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_03_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_04_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_05_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_06_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_07_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_08_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_09_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_10_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_11_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_12_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_13_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_14_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_15_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_16_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_17_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_18_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_21_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_22_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_31_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_32_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_34_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_41_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_42_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_44_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_45_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_51_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_52_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_53_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_54_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_61_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_63_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_64_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_65_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_66_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_67_bad();
	CWE197_Numeric_Truncation_Error__short_fscanf_68_bad();

	return 0;
}
