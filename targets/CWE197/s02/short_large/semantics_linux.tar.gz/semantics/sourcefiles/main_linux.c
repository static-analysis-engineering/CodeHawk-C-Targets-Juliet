#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE197_Numeric_Truncation_Error__short_large_01_good();
	CWE197_Numeric_Truncation_Error__short_large_02_good();
	CWE197_Numeric_Truncation_Error__short_large_03_good();
	CWE197_Numeric_Truncation_Error__short_large_04_good();
	CWE197_Numeric_Truncation_Error__short_large_05_good();
	CWE197_Numeric_Truncation_Error__short_large_06_good();
	CWE197_Numeric_Truncation_Error__short_large_07_good();
	CWE197_Numeric_Truncation_Error__short_large_08_good();
	CWE197_Numeric_Truncation_Error__short_large_09_good();
	CWE197_Numeric_Truncation_Error__short_large_10_good();
	CWE197_Numeric_Truncation_Error__short_large_11_good();
	CWE197_Numeric_Truncation_Error__short_large_12_good();
	CWE197_Numeric_Truncation_Error__short_large_13_good();
	CWE197_Numeric_Truncation_Error__short_large_14_good();
	CWE197_Numeric_Truncation_Error__short_large_15_good();
	CWE197_Numeric_Truncation_Error__short_large_16_good();
	CWE197_Numeric_Truncation_Error__short_large_17_good();
	CWE197_Numeric_Truncation_Error__short_large_18_good();
	CWE197_Numeric_Truncation_Error__short_large_21_good();
	CWE197_Numeric_Truncation_Error__short_large_22_good();
	CWE197_Numeric_Truncation_Error__short_large_31_good();
	CWE197_Numeric_Truncation_Error__short_large_32_good();
	CWE197_Numeric_Truncation_Error__short_large_34_good();
	CWE197_Numeric_Truncation_Error__short_large_41_good();
	CWE197_Numeric_Truncation_Error__short_large_42_good();
	CWE197_Numeric_Truncation_Error__short_large_44_good();
	CWE197_Numeric_Truncation_Error__short_large_45_good();
	CWE197_Numeric_Truncation_Error__short_large_51_good();
	CWE197_Numeric_Truncation_Error__short_large_52_good();
	CWE197_Numeric_Truncation_Error__short_large_53_good();
	CWE197_Numeric_Truncation_Error__short_large_54_good();
	CWE197_Numeric_Truncation_Error__short_large_61_good();
	CWE197_Numeric_Truncation_Error__short_large_63_good();
	CWE197_Numeric_Truncation_Error__short_large_64_good();
	CWE197_Numeric_Truncation_Error__short_large_65_good();
	CWE197_Numeric_Truncation_Error__short_large_66_good();
	CWE197_Numeric_Truncation_Error__short_large_67_good();
	CWE197_Numeric_Truncation_Error__short_large_68_good();

	CWE197_Numeric_Truncation_Error__short_large_01_bad();
	CWE197_Numeric_Truncation_Error__short_large_02_bad();
	CWE197_Numeric_Truncation_Error__short_large_03_bad();
	CWE197_Numeric_Truncation_Error__short_large_04_bad();
	CWE197_Numeric_Truncation_Error__short_large_05_bad();
	CWE197_Numeric_Truncation_Error__short_large_06_bad();
	CWE197_Numeric_Truncation_Error__short_large_07_bad();
	CWE197_Numeric_Truncation_Error__short_large_08_bad();
	CWE197_Numeric_Truncation_Error__short_large_09_bad();
	CWE197_Numeric_Truncation_Error__short_large_10_bad();
	CWE197_Numeric_Truncation_Error__short_large_11_bad();
	CWE197_Numeric_Truncation_Error__short_large_12_bad();
	CWE197_Numeric_Truncation_Error__short_large_13_bad();
	CWE197_Numeric_Truncation_Error__short_large_14_bad();
	CWE197_Numeric_Truncation_Error__short_large_15_bad();
	CWE197_Numeric_Truncation_Error__short_large_16_bad();
	CWE197_Numeric_Truncation_Error__short_large_17_bad();
	CWE197_Numeric_Truncation_Error__short_large_18_bad();
	CWE197_Numeric_Truncation_Error__short_large_21_bad();
	CWE197_Numeric_Truncation_Error__short_large_22_bad();
	CWE197_Numeric_Truncation_Error__short_large_31_bad();
	CWE197_Numeric_Truncation_Error__short_large_32_bad();
	CWE197_Numeric_Truncation_Error__short_large_34_bad();
	CWE197_Numeric_Truncation_Error__short_large_41_bad();
	CWE197_Numeric_Truncation_Error__short_large_42_bad();
	CWE197_Numeric_Truncation_Error__short_large_44_bad();
	CWE197_Numeric_Truncation_Error__short_large_45_bad();
	CWE197_Numeric_Truncation_Error__short_large_51_bad();
	CWE197_Numeric_Truncation_Error__short_large_52_bad();
	CWE197_Numeric_Truncation_Error__short_large_53_bad();
	CWE197_Numeric_Truncation_Error__short_large_54_bad();
	CWE197_Numeric_Truncation_Error__short_large_61_bad();
	CWE197_Numeric_Truncation_Error__short_large_63_bad();
	CWE197_Numeric_Truncation_Error__short_large_64_bad();
	CWE197_Numeric_Truncation_Error__short_large_65_bad();
	CWE197_Numeric_Truncation_Error__short_large_66_bad();
	CWE197_Numeric_Truncation_Error__short_large_67_bad();
	CWE197_Numeric_Truncation_Error__short_large_68_bad();

	return 0;
}
